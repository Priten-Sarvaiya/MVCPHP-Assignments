<?php

require_once 'Teacher.php';
require_once 'Student.php';

$priten = new Teacher('Priten Sarvaiya','abc');
if(!$priten->addCourse('MVCPHP'))
    echo "<br>Course is Already existed";
if(!$priten->addCourse('PYTHON'))
    echo "<br>Course is Already existed";
if(!$priten->addCourse('NODEJS'))
    echo "<br>Course is Already existed";
if(!$priten->addCourse('JAVASCRIPT'))
    echo "<br>Course is Already existed";

if(!$priten->removeCourse('JAVASCRIPT'))
    echo "<br>Course does not existed";
    
$sarvaiya = new Student('Black Perl','xyz');
$sarvaiya->addCourseGrade('MVCPHP',90);
$sarvaiya->addCourseGrade('PYTHON',91);
$sarvaiya->addCourseGrade('NODEJS',92);
$sarvaiya->printGrades();
echo "Average Grade : ".$sarvaiya->getAverageGrade();

?>