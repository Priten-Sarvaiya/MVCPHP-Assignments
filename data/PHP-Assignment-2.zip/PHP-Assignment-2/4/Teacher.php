<?php

require_once 'Person.php';

class Teacher extends Person{
	protected $numCourses=0,$courses=[];

	public function __construct($name,$address) {
        parent :: __construct($name,$address);
    }
	public function addCourse($course) {
		$r=in_array($course,$this->courses,);
		if($r)
			return false;
		else {
			array_push($this->courses, $course);
			echo "<br><br>Course Succsessfully Added";
			return true;
		}
	}
	public function removeCourse($course) {
		$r=in_array($course,$this->courses,);
		if(!$r)
			return false;
		else {
			$a=array_search($course,$this->courses);
			$this->courses=array_values($this->courses);
			unset($this->courses[$a]);
			echo "<br><br>Course Succsessfully Removed";
			return true;
		}
	}
	public function __toString() {
    	return "<br>Name : $this->name <br>Address : $this->address";
    }
}

?>