<?php

require_once 'Person.php';

class Student extends Person{
	private $numCourses=0,$courses=[],$grade=[];

	public function __construct($name,$address) {
        parent :: __construct($name,$address);
    }
	public function addCourseGrade($course,$grade) {
		array_push($this->courses, $course);
		array_push($this->grade, $grade);
		$this->numCourses++;
	}
	public function printGrades() {
		echo "<pre>";
		echo "<br><br>Courses			Mark<br>";
		foreach ($this->courses as $key => $course) {
			echo "<br>$course 			".$this->grade[$key];
		}
		echo "</pre>";	
	}
	public function getAverageGrade()
	 {
	 	$sum=0;
		foreach ($this->grade as $value);
			$sum+=$value;
		$avg=$sum/$this->numCourses;
		return $avg;
	}
	public function __toString() {
    	return "<br>Name : $this->name <br>Address : $this->address";
    }
}

?>