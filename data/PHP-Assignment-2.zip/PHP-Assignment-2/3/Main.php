<?php

require_once('CheckingAccount.php');
require_once('SavingAccount.php');

$priten=new CheckingAccount();
$priten->deposit(5124578987,1000);
$priten->withdraw(5124578987,500);
$priten->deductFee(5124578987,500);
$priten=new SavingAccount();
$priten->addInterest(5124578987);
echo $priten->getBalance(5124578987);

?>