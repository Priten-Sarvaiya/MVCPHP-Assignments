<?php

require_once('BankAccount.php');

class SavingAccount extends BankAccount {
	private $intestRate=8;

	public function addInterest($account_no) {
		if($this->accountNumber!=$account_no)
			die("<br> Invalid Account Number");
		$this->totalBalance+=($this->totalBalance*($this->intestRate/100));
		echo "<br> By adding interest, Your Balance is : $this->totalBalance";
	}
}

?>