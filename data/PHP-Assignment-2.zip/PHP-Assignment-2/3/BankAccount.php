<?php

class BankAccount {
	protected $accountNumber=5124578987,$totalBalance=5000;

	public function deposit($account_no,$money) {
		if($this->accountNumber!=$account_no)
			die("<br> Invalid Account Number");
		$this->totalBalance+=$money;
		echo "<br> After deposit, Balance is : $this->totalBalance";		

	}
	public function withdraw($account_no,$money) {
		if($this->accountNumber!=$account_no)
			die("<br> Invalid Account Number");
		if ($this->totalBalance < $money)
			die("<br> Not enough balance, in your account!"); 
		$this->totalBalance+=$money;
		echo "<br> After withdraw, Balance left : $this->totalBalance";		

	}
	public function getBalance($account_no) {
		echo "<br><br><br> Account Number : $this->accountNumber";
		echo "<br> Current Balance : $this->totalBalance";
		echo "<br> Balance :  $this->totalBalance";
	}
}

?> 