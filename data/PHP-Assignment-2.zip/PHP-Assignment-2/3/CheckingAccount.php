<?php

require_once('BankAccount.php');

class CheckingAccount extends BankAccount {
	private $fee;

	public function deductFee($account_no,$fee) {
		if($this->accountNumber!=$account_no)
			die("<br> Invalid Account Number");
		$this->fee=$fee;
		$this->totalBalance-=$this->fee;
		echo "<br> After deducting fees, Balance left : $this->totalBalance";		
	}
}

?>