<?php

require_once('Cow.php');
require_once('Lion.php');

$objcow = new Cow('abc','ghas');
$objlion = new Lion('xyz','mas');
echo $objcow->getFamily()."<br>";
echo $objcow->getFood()."<br>";
$objcow->setOwner('Priten');
echo $objcow->getOwner()."<br>";

echo $objlion->getFamily()."<br>";
echo $objlion->getFood()."<br>";


?>