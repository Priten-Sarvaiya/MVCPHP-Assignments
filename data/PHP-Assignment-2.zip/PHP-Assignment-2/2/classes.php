<?php

class EmailAddress {
	public $emailaddress;

	public function getEmailAddress() {
		return($this->emailaddress);
	}
	public function setEmailAddress($email) {
		$this->emailaddress=$email;
	}
}

class AddressDisplay {
	private $addressType,$addressText;

	public function getAddressType() {
		return $this->addressType;
	}
	public function getAddressText() {
		return $this->addressText;
	}
	public function setAddressType($email) {
		$this->addressType=gettype($email);
	}
	public function setAddressText($email) {
		$this->addressText=gettext($email);
	}
}

class EmailAddressDisplayAdapter extends AddressDisplay {

	public function __construct($email) {
		$this->setAddressType($email->emailaddress);
		$this->setAddressText($email->emailaddress);
	}
}
?>