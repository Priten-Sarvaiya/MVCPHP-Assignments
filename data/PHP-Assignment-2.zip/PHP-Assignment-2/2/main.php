<?php

require_once('classes.php');

$email = new EmailAddress();
$email->setEmailAddress("pritensarvaiya@yahoo.com");
$address = new EmailAddressDisplayAdapter($email);
echo($address->getAddressType() . "<br>");
echo($address->getAddressText());

?>