<?php

class MyClass {
    public function intro($name) {
        echo "Hello  All,  I  am $name";
    }
}

$obj = new MyClass();
$obj->intro("Priten");

?>